package com.example.groupaccounts.model;

public class Address {
	private String addr_housenumber;
	private String addr_street;
	private String addr_city;
	private String addr_country;
	
	public String getAddr_housenumber() {
		return addr_housenumber;
	}
	public void setAddr_housenumber(String addr_housenumber) {
		this.addr_housenumber = addr_housenumber;
	}
	public String getAddr_street() {
		return addr_street;
	}
	public void setAddr_street(String addr_street) {
		this.addr_street = addr_street;
	}
	public String getAddr_city() {
		return addr_city;
	}
	public void setAddr_city(String addr_city) {
		this.addr_city = addr_city;
	}
	public String getAddr_country() {
		return addr_country;
	}
	public void setAddr_country(String addr_country) {
		this.addr_country = addr_country;
	}
}
