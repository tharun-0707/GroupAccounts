package com.example.demo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpHost;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class Controller {
	@RequestMapping("/Search")
	public ModelAndView registration(Form form) throws IOException {
		
		//Getting Values from Front-End and Storing it in a Variable
		String Name = form.getName();
		String DoorNumber = form.getDoorNo();
		String StreetName = form.getStreetName();
		String CityName = form.getCityName();
		String Country = form.getCountry();
		
		
		//Adding Form Inputs into ModelAndView 
		ModelAndView mv = new ModelAndView();
		mv.addObject("Name", Name);
		mv.addObject("DoorNumber", DoorNumber);
		mv.addObject("StreetName",StreetName);
		mv.addObject("CityName", CityName);
		mv.addObject("Country", Country);
		
		
		//Printing the Values Fetched from Front-End (Front-End and Back-End Integration Check)
		System.out.println(Name);
		System.out.println(DoorNumber);
		System.out.println(StreetName);
		System.out.println(CityName);
		System.out.println(Country);
		
		
		//Setting-up the ElasticSearch Client to Work
		RestHighLevelClient client = new RestHighLevelClient(RestClient.builder(new HttpHost("localhost", 9200, "http")));
		
		
		//Searching by Index Name
		SearchRequest searchRequest = new SearchRequest("uk_filter"); 
		System.out.println("Connected");
		
		
		//Filtering Using Queries
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder = searchSourceBuilder.query(QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("addr_city", CityName)).must(QueryBuilders.matchPhraseQuery("addr_street", StreetName)).must(QueryBuilders.matchPhraseQuery("addr_housenumber", DoorNumber)));
		System.out.println("Query Running");
		searchRequest.source(searchSourceBuilder);
		SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
		org.elasticsearch.search.SearchHit[] searchHits = searchResponse.getHits().getHits();
		
		
			for (org.elasticsearch.search.SearchHit hit : searchHits) {
			//System.out.println(hit.getSourceAsString());
			System.out.println(hit.getSourceAsMap().keySet());
			
			
			
			//Printing the values found from DataBase (Back-End DataBase Integration Check)
			System.out.println("-------------------------------");
			System.out.println(hit.getSourceAsMap().get("location"));
			System.out.println("OSM_ID is : " + hit.getSourceAsMap().get("osm_id"));
			System.out.println("Score is : " + hit.getScore());
			System.out.println("DoorNumber is :" + hit.getSourceAsMap().get("addr_housenumber"));
			System.out.println("Street Name is : " + hit.getSourceAsMap().get("addr_street"));
			System.out.println("City Name is : " + hit.getSourceAsMap().get("addr_city"));
			System.out.println("PostCode is : " + hit.getSourceAsMap().get("addr_postcode"));
			System.out.println("Name is : " + hit.getSourceAsMap().get("name"));
			System.out.println("Amenity is : " + hit.getSourceAsMap().get("amenity"));
			System.out.println("OSM ID is : " + hit.getSourceAsMap().get("osm_id"));
					
			
			
			
			//Storing the values fetched into a Map for splitting
			Map CoordinatesLoc = (Map) hit.getSourceAsMap().get("location");
			String coordinates = CoordinatesLoc.get("coordinates").toString();
			System.out.println(coordinates);
			
			//Splitting operation to fetch Coordinates from Location
			String str = coordinates.replaceAll("[^-0-9.]+", " ");
			System.out.println(str);
			String[] location = (str.trim().split(" "));
			//System.out.println(Arrays.asList(str.trim().split(" ")));
			String lat = location[0];
			String lon = location[1];
			System.out.println("Lat : "+lat);
			System.out.println("Lon : "+lon);
					
			
			//Assigning Values into HashMap for Passing it to Front-End
		   HashMap<String, String> locationpointer = new HashMap<String, String>();
		   locationpointer.put("Latitude", lat);
		   locationpointer.put("Longitude", lon);
		   locationpointer.put("Name", Name);
		   locationpointer.put("DoorNumber", DoorNumber);
		   locationpointer.put("CityName", CityName);
		   locationpointer.put("StreetName", StreetName);
		   locationpointer.put("Country", Country);
		   mv.addAllObjects(locationpointer);
		   
		   
			}
			
			//Setting the ViewPage
			mv.setViewName("Output.jsp"); 
			return mv;	
	}
}
