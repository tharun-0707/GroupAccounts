package com.example.groupaccounts.model;

public class MultipleAddressData {
	private String[] houseNumbers;
	private String[] streetNames;
	private String country;
	private String city;
	public String[] getHouseNumbers() {
		return this.houseNumbers;
	}
	public void setHouseNumbers(String[] houseNumbers) {
		this.houseNumbers = houseNumbers;
	}
	public String[] getStreetNames() {
		return this.streetNames;
	}
	public void setStreetNames(String[] streetNames) {
		this.streetNames = streetNames;
	}
	public String getCountry() {
		return this.country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return this.city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
}
