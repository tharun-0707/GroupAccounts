package com.example.groupaccounts.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpHost;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.groupaccounts.model.Address;
import com.example.groupaccounts.model.MultipleAddress;
import com.example.groupaccounts.model.MultipleAddressData;
import com.example.groupaccounts.services.SplitterService;
@RestController
public class MainController {
	@Autowired
	SplitterService splitter;
	
	@Autowired
	MultipleAddress multiAddress;
	
	String[] houseNoArr;
	String[] streetArr;
	String[] cityArr;
	String[] countryArr;
	String city;
	String country;
	String addressData = null;
	SearchHit[] searchHits = null;
	String lat = null;
	String lon = null;
	/*@GetMapping(value="/api/markLocation")
	public ModelAndView showLocation(@ModelAttribute("address") Address address) throws IOException
	{
		ModelAndView mv = new ModelAndView();
		String lat = "";
		String lon = "";
 		String addressData = null;
 		SearchHit[] searchHits = null;
 		houseNoArr = splitter.splitData(address.getAddr_housenumber());
 		streetArr = splitter.splitData(address.getAddr_street());
 		cityArr = splitter.splitData(address.getAddr_city());
 		countryArr = splitter.splitData(address.getAddr_country());
 		int len = houseNoArr.length;
		List<MultipleAddress> multiAddr = new ArrayList<MultipleAddress>();
		RestHighLevelClient client = new RestHighLevelClient(RestClient.builder(new HttpHost("localhost", 9200, "http")));
		SearchRequest searchRequest = new SearchRequest("unitedkingdom(filtered)");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		for(int i=0;i<len;i++)
		{
			QueryBuilder query = searchSourceBuilder.query(QueryBuilders.boolQuery().must(QueryBuilders.matchPhraseQuery("addr_country", countryArr[i])).must(QueryBuilders.matchPhraseQuery("addr_city", cityArr[i])).must(QueryBuilders.matchPhraseQuery("addr_street", streetArr[i])).must(QueryBuilders.matchPhraseQuery("addr_housenumber", houseNoArr[i]))).query();
			searchSourceBuilder.query(query);
			searchRequest.source(searchSourceBuilder);
			SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
			searchHits = searchResponse.getHits().getHits();
			addressData = houseNoArr[i].concat(";").concat(streetArr[i]).concat(";").concat(cityArr[i]).concat(";").concat(countryArr[i]);
			for(SearchHit hit:searchHits)
			{
				System.out.println(hit);
				Map coordinateLoc = (Map) hit.getSourceAsMap().get("location");
				String coordinates = coordinateLoc.get("coordinates").toString();
				String coordinate = coordinates.replaceAll("[^-0-9.]+", " ");
				String[] location=(coordinate.trim().split(" "));
				lat = location[0];
				lon = location[1];
				multiAddr.add(new MultipleAddress(lat,lon,addressData));
			}
		}
		mv.addObject("addressList",multiAddr);
		mv.setViewName("/html/map.jsp");
		return mv;
	}*/
	
	@PostMapping(value="/api/markLoc")
	public void markLocation(@ModelAttribute("multiArr") MultipleAddressData multiArr) throws IOException
	{
		houseNoArr = multiArr.getHouseNumbers();
		streetArr = multiArr.getStreetNames();
		city = multiArr.getCity();
		country = multiArr.getCountry();
	}
	@PostMapping(value="/api/markLocData")
	public ModelAndView markLocations() throws IOException
	{
		ModelAndView mv = new ModelAndView();
		int len = houseNoArr.length;
		List<MultipleAddress> multiAddr = new ArrayList<MultipleAddress>();
		RestHighLevelClient client = new RestHighLevelClient(RestClient.builder(new HttpHost("localhost", 9200, "http")));
		SearchRequest searchRequest = new SearchRequest("unitedkingdom(filtered)");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		for(int i=0;i<len;i++)
		{
			QueryBuilder query = searchSourceBuilder.query(QueryBuilders.boolQuery().must(QueryBuilders.matchPhraseQuery("addr_country", country)).must(QueryBuilders.matchPhraseQuery("addr_city", city)).must(QueryBuilders.matchPhraseQuery("addr_street", streetArr[i])).must(QueryBuilders.matchPhraseQuery("addr_housenumber", houseNoArr[i]))).query();
			searchSourceBuilder.query(query);
			searchRequest.source(searchSourceBuilder);
			SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
			searchHits = searchResponse.getHits().getHits();
			addressData = houseNoArr[i].concat(";").concat(streetArr[i]).concat(";").concat(city).concat(";").concat(country);
			for(SearchHit hit:searchHits)
			{
				System.out.println(hit);
				Map coordinateLoc = (Map) hit.getSourceAsMap().get("location");
				String coordinates = coordinateLoc.get("coordinates").toString();
				String coordinate = coordinates.replaceAll("[^-0-9.]+", " ");
				String[] location=(coordinate.trim().split(" "));
				lat = location[0];
				lon = location[1];
				multiAddr.add(new MultipleAddress(lat,lon,addressData));
			}
		}
		mv.addObject("addressList",multiAddr);
		mv.setViewName("/html/map.jsp");
		return mv;
	}
}
