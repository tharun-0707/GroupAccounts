package com.example.groupaccounts.model;

import org.springframework.stereotype.Component;

@Component
public class MultipleAddress {
	private String address;
	private String latitude;
	private String longitude;
	
	public MultipleAddress()
	{
		
	}
	public MultipleAddress(String latitude,String longitude,String address)
	{
		this.address = address;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	public void setAddress(String address)
	{
		this.address = address;
	}
	public void setLatitude(String latitude)
	{
		this.latitude = latitude;
	}
	public void setLongitude(String longitude)
	{
		this.longitude = longitude;
	}
	public String getAddress() {
		return address;
	}
	public String getLatitude() {
		return latitude;
	}
	public String getLongitude() {
		return longitude;
	}
}
