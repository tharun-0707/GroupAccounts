package com.example.groupaccounts.services;

import org.springframework.stereotype.Service;

@Service
public class SplitterService {
	public String[] splitData(String data)
	{
		String[] splittedArr=(data.trim().split(","));
		return splittedArr;
	}
}
