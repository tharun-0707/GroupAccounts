//Initialize map with some coordinates and setting view
var routeArray = [];
var mymap = L.map('mapid').setView([51.5285582, -0.2416815],10);
L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap contributors'
}).addTo(mymap);
for(var i=0;i<length;i++)
{
	var marker = L.marker([longitudeData[i], latitudeData[i]]).addTo(mymap);
	marker.bindPopup(addressData[i]).openPopup();
	routeArray.push(L.latLng(longitudeData[i], latitudeData[i]));
}
console.log(routeArray);
L.Routing.control({
		waypoints: routeArray,
	    routeWhileDragging: true,
	}).addTo(mymap);
