package com.example.demo;


public class Form {
	private String Name;
	private String DoorNo;
	private String StreetName;
	private String CityName;
	private String Country;
	
	
	public Form(String name, String doorNo, String streetName, String cityName, String country) {
		super();
		Name = name;
		DoorNo = doorNo;
		StreetName = streetName;
		CityName = cityName;
		Country = country;
	}


	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}

	public String getDoorNo() {
		return DoorNo;
	}
	public void setDoorNo(String doorNo) {
		DoorNo = doorNo;
	}

	public String getStreetName() {
		return StreetName;
	}
	public void setStreetName(String streetName) {
		StreetName = streetName;
	}

	public String getCityName() {
		return CityName;
	}
	public void setCityName(String cityName) {
		CityName = cityName;
	}

	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}


	@Override
	public String toString() {
		return "Form [Name=" + Name + ", DoorNo=" + DoorNo + ", StreetName=" + StreetName + ", CityName=" + CityName
				+ ", Country=" + Country + "]";
	}
	
	
	
	
}
