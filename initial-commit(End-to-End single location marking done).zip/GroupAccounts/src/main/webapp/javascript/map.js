//Initialize map with some coordinates and setting view
var mymap = L.map('mapid').setView([longitude, latitude], 18);
L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap contributors'
}).addTo(mymap);
var marker = L.marker([longitude, latitude]).addTo(mymap);
marker.bindPopup(houseNo+";"+street+";"+city+";"+country).openPopup();